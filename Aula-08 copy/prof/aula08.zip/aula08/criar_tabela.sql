CREATE TABLE usuarios (
	nome TEXT
	idade INT
	senha TEXT
)