INSERT INTO public.usuarios (
	nome,
	senha,
	idade
) VALUES (
	'Maycon',
	'123',
	25
);