SELECT nome, idade, senha
	FROM public.usuarios WHERE nome='Maria' AND idade=25;