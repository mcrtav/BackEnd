- Criar uma tabela chamada pessoas
  - nome (texto)
  - idade (inteiro)
  - altura (decimal)
- Inserir dados na tabela
- Deletar dados da tabela
- Atualizar dados da tabela

CRUD

C - Create (criar) / insert
R - Read (ler) / select
U - Update (atualizar) / update
D - Delete (deletar) / delete
